const { render } = require("pug");
const validator = require('validator');
const bcrypt = require('bcrypt');
const db = require('../db/config');

exports.login = async(req,res) =>{

    const errores = {};
    var users_data = {};
    var {correo, password} = req.body;
    if(correo != '' && password != ''){

        const docRef = db.collection('evaluadores');
        const correo_cloud = await docRef.where('correo', '==', correo).get();
        
        if(correo_cloud._size == 0){
            errores.text = 'No existe un evaluador registrado con este correo electrónico.';
            req.session.errores_login = errores; 
            res.redirect('/');
        }else{
            correo_cloud.forEach(doc => {
                users_data = doc.data();
              });

              const valid_password = await bcrypt.compare(password, users_data.password);
              if(valid_password){
                  req.session.datos_login = users_data;
                  req.session.isloged = true;
                  res.redirect('/profile');
              }else{
                    errores.text = 'La contraseña es incorrecta';
                    req.session.errores_login = errores; 
                    res.redirect('/');
              }

        }
    
    }else{
        res.redirect('/');
    }


}

exports.profile = async(req,res)=>{

    const isloged = req.session.isloged;
    var datos_login = req.session.datos_login;
    var nombre = "";

    if (typeof(datos_login) != "undefined"){
        var nombre = datos_login.nombre + " " + datos_login.apellido;
        delete req.session.mensaje;
        const docRef = db.collection('usuarios');
        const usuarios = await docRef.where('evaluador', '==', nombre).get();
        var users = [];
        if(usuarios._size > 0){
            usuarios.forEach(doc => {
                users.push(doc.data());
              });
        }
        
    }

    if( isloged == true){
        if(users.length > 0){
            res.render('profile.pug',{
                datos_login,
                nombre,
                users
            });
        }
        else{
            res.render('profile.pug',{
                datos_login,
                nombre
            });
        }

    }else{
        res.redirect('/');
    }

}

exports.micuenta = (req,res) =>{

}

exports.contacto = (req,res) =>{

}

exports.cerrarsesion = (req,res) =>{
    delete req.session.isloged;
    delete req.session.datos_login;

    res.redirect('/');

}

exports.crearev = (req,res) =>{

    const isloged = req.session.isloged;
    var datos_login = req.session.datos_login;
    var nombre = "";
    if (typeof(datos_login) != "undefined"){
        var nombre = datos_login.nombre + " " + datos_login.apellido;
    }

    if( isloged == true){

        var datos_ev = req.session.datos_ev;
        var errores_ev = req.session.errores_ev;
        var tiempo = req.session.tiempo;
        delete req.session.tiempo;
        delete req.session.datos_ev;
        delete req.session.errores_ev;
        if (typeof(errores_ev) != "undefined"){

        }else{
            errores_ev={};
        }

        if (typeof(datos_ev) != "undefined"){

        }else{
            datos_ev={};
        }

        if (typeof(tiempo) != "undefined"){

        }else{
            tiempo={};
        }

        res.render('crearev.pug',{
            datos_login,
            nombre,
            datos_ev,
            errores_ev,
            tiempo
        });

    }else{
        res.redirect('/');
    }

}

exports.validarev = async (req,res) =>{

    var {nombre, identificacion, serial, org, horas, minutos, evaluador} = req.body;
    serial = serial.toString().toUpperCase();

    const isloged = req.session.isloged;
    var datos_login = req.session.datos_login;
    var error = 0;
    var errors = {}
    var datos = {}
    var hora = "";
    if (typeof(datos_login) != "undefined"){
        Nombre_ev = datos_login.nombre + " " + datos_login.apellido;
    }else{
        isloged == false;
    }

    if( isloged == true){
        
        //Validación
        const docRef = db.collection('evaluadores');
        if(validator.matches(nombre,/^[a-zA-ZÀ-ÿ\u00f1\u00d1]+(\s*[a-zA-ZÀ-ÿ\u00f1\u00d1]*)*[a-zA-ZÀ-ÿ\u00f1\u00d1]+$/) && nombre != ""){
            datos.nombre = nombre;
        }
        else{
            errors.nombre = 'El nombre no es válido o el campo "Nombre" está vacio.';
            error = error +1;
        }

        if(validator.matches(identificacion,/^[0-9]{5,}$/)){
            datos.identificacion = identificacion;
        }
        else{
            errors.identificacion = 'La identificación no es válida o el campo "identificación" está vacio.';
            error = error +1;
        }

        if(validator.matches(serial,/^[0-9a-zA-Z]{4,}$/)){

            const serialRef = db.collection('seriales').doc(serial);
            const doc = await (await serialRef.get());

            if(!doc.exists){
                errors.serial = 'El numero de serial' + serial +' no existe en la base de datos';
                error = error +1;
            }else{
                const veriref = db.collection('usuarios');
                const usuarios = await veriref.where('serial', '==', serial).get();;
                if(usuarios._size == 0){
                    datos.serial = serial;
                }else{
                    errors.serial = 'El numero de serial ' + serial +' existe en otro usuario';
                    error = error +1;
                }

            }
        }
        else{
            errors.serial = 'El serial no es válido o el campo "serial" está vacio.';
            error = error +1;
        }

        if(validator.matches(org,/^[0-9a-zA-ZÀ-ÿ\u00f1\u00d1]+(\s*[0-9a-zA-ZÀ-ÿ\u00f1\u00d1]*)*[0-9a-zA-ZÀ-ÿ\u00f1\u00d1]{2,}$/)){
            datos.org = org;
        }
        else{
            errors.org = 'La organzación no es válida o el campo "organzación" está vacio.';
            error = error +1;
        }

        if(validator.matches(horas,/^[0-9]+([.][0-9]+)?$/)){

        }
        else{
            errors.tiempo = 'Los campos "Horas" y "Minutos" solo deben contener números';
            error = error +1;
        }    

        if(validator.matches(minutos,/^[0-9]+([.][0-9]+)?$/)){

        }
        else{
            errors.tiempo = 'Los campos "Horas" y "Minutos" solo deben contener números';
            error = error +1;
        }    

        if(evaluador ==  Nombre_ev){
            datos.evaluador = evaluador;
        }
        else{
            errors.evaluador = 'El evaluador no coincide';
            error = error +1;
        }    

        if(error == 0){
            datos.tiempo = horas + ":" + minutos;
            const docRef = await db.collection('usuarios').doc(datos.identificacion);
            docRef.set(datos);
            res.redirect('/profile/crearEv');
        }else{
            var tiempo = {};
            tiempo.horas = horas;
            tiempo.minutos = minutos;
            req.session.tiempo = tiempo;
            req.session.errores_ev = errors;
            req.session.datos_ev = datos;
            res.redirect('/profile/crearEv');
        }


    }else{
        res.redirect('/');
    }

}

exports.BuscarId = async (req,res) =>{

    const isloged = req.session.isloged;
    var datos_login = req.session.datos_login;
    var nombre = "";
    var str_hora = "";
    if (typeof(datos_login) != "undefined"){
        var nombre = datos_login.nombre + " " + datos_login.apellido;
        const id = req.params.id;
        const docRef = db.collection('usuarios');
        const usuarios = await docRef.where('evaluador', '==', nombre).where('identificacion','==',id).get();
        var users = [];
        if(usuarios._size > 0){
            usuarios.forEach(doc => {
                users.push(doc.data());

              });
        }
        
    }

    if( isloged == true){
        if(users.length > 0){
            res.render('profile.pug',{
                datos_login,
                nombre,
                users
            });
        }
        else{
            res.redirect('/profile');
        }

    }else{
        res.redirect('/');
    }
}

exports.UpdateiId = async(req,res) =>{

    const isloged = req.session.isloged;
    var datos_login = req.session.datos_login;
    var mensaje = req.session.mensaje;
    delete req.session.mensaje;
    var nombre = "";

    if (typeof(datos_login) != "undefined"){
        var nombre = datos_login.nombre + " " + datos_login.apellido;
        const id = req.params.id;
        const docRef = db.collection('usuarios');
        const usuarios = await docRef.where('evaluador', '==', nombre).where('identificacion','==',id).get();
        var usersupdate = [];
        if(usuarios._size > 0){
            usuarios.forEach(doc => {
                var datos = doc.data();
                var tiempo_a = [];
                str_hora = datos.tiempo;
                tiempo_a = str_hora.split(":");
                datos.horas = tiempo_a[0];
                datos.minutos = tiempo_a[1];
                usersupdate.push(datos);
              });
        }
        
    }

    if(typeof(mensaje) != "undefined"){
        mensaje = mensaje;
    }
    else{
        mensaje = "";
    }

    if( isloged == true){
        if(usersupdate.length > 0){
            res.render('profile.pug',{
                datos_login,
                nombre,
                usersupdate,
                mensaje
            });
        }
        else{
            res.redirect('/profile');
        }

    }else{
        res.redirect('/');
    }
}

exports.updateUser = async(req,res) =>{

    const isloged = req.session.isloged;
    var datos_login = req.session.datos_login;

    if (typeof(datos_login) != "undefined"){
        var nombre = datos_login.nombre + " " + datos_login.apellido;
    }

    if( isloged == true){
        var {name, identificacion, org, serial, horas, minutos, evaluador} = req.body;
        serial = serial.toString().toUpperCase();
        if(serial == ""){
            serial = "NINGUNO";
        }
        const serialRef = db.collection('seriales').doc(serial);
        const doc = await serialRef.get();

        if(!doc.exists){
            req.session.mensaje =  "El serial "+ serial +" no existe en la base de datos";
            res.redirect('/profile/update/' + identificacion);

        }else{
            if(horas == ""){
                horas = "00";
            }
            if(minutos == ""){
                minutos = "00";
            }
                
            tiempo = horas + ":" + minutos;
            var info_actualizar = {}
            req.session.mensaje = "La evaluación de " + name +" ha sido actualizada";
            info_actualizar.serial = serial;
            info_actualizar.tiempo = tiempo;
            const docRef = await db.collection('usuarios').doc(identificacion);
            docRef.update(info_actualizar);
            res.redirect('/profile');
        }

    }else{
        res.redirect('/');
    }
}

exports.updateTerminarId = async(req,res)=>{

    const isloged = req.session.isloged;
    var datos_login = req.session.datos_login;
    if (typeof(datos_login) != "undefined"){
        var nombre = datos_login.nombre + " " + datos_login.apellido;
    }

    if( isloged == true){
        const id = req.params.id;
        const docRef = await db.collection('usuarios').doc(id);
        terminar = {};
        terminar.serial = "NINGUNO";
        terminar.tiempo = "00:00";
        docRef.update(terminar);
        res.redirect('/profile');
    }else{
        res.redirect('/');
    }

}

exports.eliminarId = async(req,res)=>{
    const isloged = req.session.isloged;
    var datos_login = req.session.datos_login;
    if (typeof(datos_login) != "undefined"){
        var nombre = datos_login.nombre + " " + datos_login.apellido;
    }
    if( isloged == true){

        const id = req.params.id;
        const docRef =  db.collection('usuarios').doc(id);
        const delete_user = await (await docRef.get()).data();
        if(delete_user){
            res.render('profile.pug',{
                datos_login,
                nombre,
                delete_user
            });
        }else{
            res.redirect('/profile');
        }


    }else{
        res.redirect('/');
    }

}

exports.eliminarEvId = async(req,res) =>{
    const isloged = req.session.isloged;
    var datos_login = req.session.datos_login;
    if (typeof(datos_login) != "undefined"){
        var nombre = datos_login.nombre + " " + datos_login.apellido;
    }
    if( isloged == true){
        const id = req.params.id;
        const docRef = await db.collection('usuarios').doc(id);
        docRef.delete();
        res.redirect('/profile');
    }
    else{
        res.redirect('/');
    }
}

exports.cuenta = (req,res) =>{
    const isloged = req.session.isloged;
    var datos_login = req.session.datos_login;
    const datos_login_new = req.session.datos_login_new;
    const isvalidated = req.session.isvalidated;
    const errores = req.session.errores;
    delete req.session.errores;
    delete req.session.datos_login_new;
    delete req.session.isvalidated;

    if (typeof(datos_login) != "undefined"){
        var nombre = datos_login.nombre + " " + datos_login.apellido;
    }
    if( isloged == true){
        res.render('cuenta.pug',{
            datos_login,
            nombre,
            datos_login_new,
            isvalidated,
            errores
        });
    }
    else{
        res.redirect('/');
    }

}

exports.validarmiCuenta = async(req,res) =>{

    const isloged = req.session.isloged;
    var datos_login = req.session.datos_login;
    if (typeof(datos_login) != "undefined"){
        var nombre = datos_login.nombre + " " + datos_login.apellido;
    }
    if( isloged == true){

        const {name,apellido,org,correo} = req.body;
        var errores = {};
        var error = 0;

        if(validator.matches(name,/^[a-zA-ZÀ-ÿ\u00f1\u00d1]+(\s*[a-zA-ZÀ-ÿ\u00f1\u00d1]*)*[a-zA-ZÀ-ÿ\u00f1\u00d1]+$/) && name != ""){

        }else{
            errores.nombre = 'El campo "Nombres" está vacio o no es valido.';
            error = error +1;
        }

        if(validator.matches(apellido,/^[a-zA-ZÀ-ÿ\u00f1\u00d1]+(\s*[a-zA-ZÀ-ÿ\u00f1\u00d1]*)*[a-zA-ZÀ-ÿ\u00f1\u00d1]+$/) && apellido != ""){

        }else{
            errores.apellido = 'El campo "Apellidos" está vacio o no es valido.';
            error = error +1;
        }

        if(validator.matches(org,/^[0-9a-zA-ZÀ-ÿ\u00f1\u00d1]+(\s*[0-9a-zA-ZÀ-ÿ\u00f1\u00d1]*)*[0-9a-zA-ZÀ-ÿ\u00f1\u00d1]+$/) && org != ""){

        }else{
            errores.org = 'El campo "Organización" está vacio.';
            error = error +1;
        }

        if(validator.isEmail(correo) && correo != ""){
        
            const docRef = db.collection('evaluadores');
            const correo_cloud = await docRef.where('correo', '==', correo).get();
            if(correo_cloud._size == 0){

            }else{
                if(correo == datos_login.correo){

                }else{
                    errores.correo = "Este correo esta siendo utilizado por otro usuario.";
                    error = error +1;
                }
            }
        }else{
            errores.correo = 'El correo no es válido o el campo "Correo electrónico" está vacio.';
            error = error +1;
        }

        if(error == 0){
            var datos_login_new = {};
            datos_login_new.nombre = name;
            datos_login_new.apellido = apellido;
            datos_login_new.org = org;
            datos_login_new.correo = correo;
            req.session.datos_login_new = datos_login_new;
            req.session.isvalidated = true;
            res.redirect('/profile/micuenta');
        }else{
            req.session.errores = errores;
            res.redirect('/profile/micuenta');
        }

    }
    else{
        res.redirect('/');
    }

}