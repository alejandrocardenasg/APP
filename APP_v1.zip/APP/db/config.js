const firestore = require('firebase-admin');
const path = require('path');

//Path de llave de acceso a la base de datos
const key = path.resolve(__dirname, './tesismlac-7136f6068052.json');

firestore.initializeApp({
    credential: firestore.credential.cert(key)
  });

const db = firestore.firestore();

module.exports = db;