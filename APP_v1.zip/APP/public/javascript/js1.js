const btn_act = document.getElementById("btn_act");
const nombre = document.getElementById("identificacion");

btn_act.addEventListener('click', () =>{
    console.log(user.identificacion);
})


